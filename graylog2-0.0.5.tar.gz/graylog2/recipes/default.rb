# Install the Graylog2 server component by default
include_recipe "graylog2::server"
